Nexus AI Backend with PostgreSQL and Swagger.
