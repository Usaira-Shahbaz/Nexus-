from flask_restx import Namespace, Resource, fields
from models.ad_model import Ad
from extensions import db
api = Namespace('ads', description='Ads CRUD API')


ad_model=api.model('Ad',{
    'id': fields.Integer(readonly=True),
    'title': fields.String,
    'description': fields.String,
    'image_url': fields.String
})

@api.route('/')
class AdsList(Resource):
    @api.marshal_list_with(ad_model)
    def get(self): return Ad.query.all()

    @api.expect(ad_model)
    @api.marshal_with(ad_model)
    def post(self):
        data=api.payload
        ad=Ad(**data)
        db.session.add(ad)
        db.session.commit()
        return ad

@api.route('/<int:id>')
class AdsItem(Resource):
    @api.marshal_with(ad_model)
    def get(self,id): return Ad.query.get_or_404(id)

    @api.expect(ad_model)
    @api.marshal_with(ad_model)
    def put(self,id):
        ad=Ad.query.get_or_404(id)
        for k,v in api.payload.items(): setattr(ad,k,v)
        db.session.commit(); return ad

    def delete(self,id):
        ad=Ad.query.get_or_404(id)
        db.session.delete(ad); db.session.commit()
        return {'message':'deleted'}
