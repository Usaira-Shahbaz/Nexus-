from flask import Flask
from config import Config
from extensions import db
from api.ads_api import api as ads_ns
from flask_restx import Api

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)

    api = Api(
        app,
        version='1.0',
        title='Nexus AI API',
        description='Swagger documentation for Ads API',
        doc='/docs'  # Swagger URL
    )

    # IMPORTANT — include trailing slash
    api.add_namespace(ads_ns, path='/api/ads/')

    return app
