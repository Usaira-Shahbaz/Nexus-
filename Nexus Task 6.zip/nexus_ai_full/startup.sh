#!/bin/bash
gunicorn --bind=0.0.0.0 --timeout 120 run:app
