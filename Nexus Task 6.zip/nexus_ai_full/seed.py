from app import create_app
from extensions import db
from models.ad_model import Ad
app=create_app()
with app.app_context():
    db.drop_all(); db.create_all()
    ads=[Ad(title='Welcome',description='Namal University',image_url='url1'),
         Ad(title='Admissions',description='Apply 2025',image_url='url2')]
    db.session.add_all(ads); db.session.commit()
    print('Seeded!')
