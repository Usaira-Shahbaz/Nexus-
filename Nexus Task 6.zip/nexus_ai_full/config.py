import os
from dotenv import load_dotenv
load_dotenv()
class Config:
    SQLALCHEMY_DATABASE_URI = 'postgresql://hussain:1234@localhost:5432/nexus_ai_db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    RESTX_MASK_SWAGGER = False  # Required for Swagger UI
